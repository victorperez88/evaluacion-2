from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "dev-not-secret"
    # Blueprints or routes are added in main.py
    return app
