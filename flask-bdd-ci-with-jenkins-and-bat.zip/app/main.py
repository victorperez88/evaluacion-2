from flask import Flask, jsonify, request
from .auth import check_credentials

app = Flask(__name__)

@app.get("/")
def root():
    return jsonify(status="ok", message="Demo Flask-BDD-CI"), 200

@app.get("/login")
def login_form():
    return jsonify(message="Login endpoint listo"), 200

@app.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    user = data.get("username")
    pwd = data.get("password")
    if check_credentials(user, pwd):
        return jsonify(auth="ok", user=user), 200
    return jsonify(auth="fail", error="Credenciales inválidas"), 401
