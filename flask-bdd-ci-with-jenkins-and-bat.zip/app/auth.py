# Lógica ultra simple de autenticación para demo
# En un sistema real, usarías hashing de contraseñas, DB, CSRF, etc.
USERS = {
    "adolfito": "s3cret",
    "tester": "123456"
}

def check_credentials(username: str, password: str) -> bool:
    if username is None or password is None:
        return False
    return USERS.get(username) == password
