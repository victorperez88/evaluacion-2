$ErrorActionPreference = "Stop"

python -m venv .venv
. .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# Levantar Flask en una ventana separada (opcional)
$env:FLASK_APP = "app.main:app"
Start-Process powershell -ArgumentList '-NoExit','-Command','. .\.venv\Scripts\Activate.ps1; $env:FLASK_APP="app.main:app"; flask run'

# Pruebas unitarias + HTML
pytest -q --cov=app --cov-report=term-missing --html=reports/pytest-report.html --self-contained-html

# BDD + HTML
behave -f html -o reports/behave-report.html

# Performance (headless)
locust -f performance/locustfile.py --headless -u 10 -r 2 -t 30s --csv=reports/locust --only-summary
