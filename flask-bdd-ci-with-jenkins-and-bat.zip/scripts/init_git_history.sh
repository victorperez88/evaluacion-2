#!/usr/bin/env bash
set -euo pipefail

REPO_NAME="${1:-flask-bdd-ci}"

if ! command -v git >/dev/null 2>&1; then
  echo "git no está instalado o no está en PATH." >&2
  exit 1
fi

CUR_DIR="$(basename "$PWD")"
if [[ "$CUR_DIR" != "$REPO_NAME" ]]; then
  echo "Renombrando carpeta '$CUR_DIR' -> '$REPO_NAME'..."
  cd ..
  mv "$CUR_DIR" "$REPO_NAME"
  cd "$REPO_NAME"
fi

git init
git add .
git commit -m "chore: bootstrap project (Flask + PyTest + Behave + Locust + CI)"

git checkout -b feat/auth-endpoints
git add app/main.py app/auth.py tests/test_app.py features/login.feature features/steps/login_steps.py
git commit -m "feat(auth): endpoints /login GET/POST + tests y escenarios BDD"

git checkout -b ci/setup
git add .github/workflows/ci.yml Jenkinsfile
git commit -m "ci: GitHub Actions + Jenkinsfile (lint, tests, BDD, performance, artifacts)"

git checkout -b docs/readme
git add README.md
git commit -m "docs: instrucciones de uso, pruebas, BDD y CI"

git branch -M main
echo "Repositorio listo. Para asociar remoto:"
echo "  git remote add origin <URL-DEL-REPO>"
echo "  git push -u origin main"
