Param(
  [string]$RepoName = "flask-bdd-ci"
)
# Usage:
#   pwsh -File scripts\init_git_history.ps1 -RepoName my-flask-bdd-ci
# or right-click Run with PowerShell (needs git installed and in PATH).
$ErrorActionPreference = "Stop"

if (!(Get-Command git -ErrorAction SilentlyContinue)) {
  Write-Error "git no está instalado o no está en PATH."
}

# Renombrar carpeta opcionalmente
$current = Split-Path -Leaf (Get-Location)
if ($current -ne $RepoName) {
  Write-Host "Renombrando carpeta '$current' -> '$RepoName'..."
  $parent = Split-Path -Parent (Get-Location)
  Set-Location $parent
  Rename-Item -Path $current -NewName $RepoName -Force
  Set-Location $RepoName
}

git init
git add .
git commit -m "chore: bootstrap project (Flask + PyTest + Behave + Locust + CI)"

# Simular iteraciones reales
git checkout -b feat/auth-endpoints
git add app/main.py app/auth.py tests/test_app.py features/login.feature features/steps/login_steps.py
git commit -m "feat(auth): endpoints /login GET/POST + tests y escenarios BDD"

git checkout -b ci/setup
git add .github/workflows/ci.yml Jenkinsfile
git commit -m "ci: GitHub Actions + Jenkinsfile (lint, tests, BDD, performance, artifacts)"

git checkout -b docs/readme
git add README.md
git commit -m "docs: instrucciones de uso, pruebas, BDD y CI"

git branch -M main
Write-Host "Repositorio listo. Para asociar remoto:"
Write-Host "  git remote add origin <URL-DEL-REPO>"
Write-Host "  git push -u origin main"
