# Usamos el test_client de Flask sin lanzar un server real
from app.main import app

def before_all(context):
    context.client = app.test_client()
