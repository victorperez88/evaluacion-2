import json
from behave import given, when, then

@given("la API está viva")
def step_alive(context):
    res = context.client.get("/")
    assert res.status_code == 200

@when("consulto GET /login")
def step_get_login(context):
    context.response = context.client.get("/login")

@then("la respuesta es 200")
def step_resp_200(context):
    assert context.response.status_code == 200

@when('hago POST /login con "{user}" y "{pwd}"')
def step_do_login(context, user, pwd):
    body = {"username": user, "password": pwd}
    context.response = context.client.post("/login", data=json.dumps(body),
                                           content_type="application/json")

@then('el código es {code:d}')
def step_code_is(context, code):
    assert context.response.status_code == code
