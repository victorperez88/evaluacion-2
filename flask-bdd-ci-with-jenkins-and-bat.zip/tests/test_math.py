import pytest

def sumar(a, b):
    return a + b

def restar(a, b):
    return a - b

def test_sumar_atomico():
    assert sumar(2, 3) == 5

def test_restar_atomico():
    assert restar(10, 4) == 6
