import json
from app.main import app

def test_root_endpoint():
    client = app.test_client()
    r = client.get("/")
    assert r.status_code == 200
    assert r.json.get("status") == "ok"

def test_login_ok():
    client = app.test_client()
    r = client.post("/login", data=json.dumps({"username":"tester","password":"123456"}),
                    content_type="application/json")
    assert r.status_code == 200
    assert r.json.get("auth") == "ok"
    assert r.json.get("user") == "tester"

def test_login_fail():
    client = app.test_client()
    r = client.post("/login", data=json.dumps({"username":"tester","password":"bad"}),
                    content_type="application/json")
    assert r.status_code == 401
    assert r.json.get("auth") == "fail"
