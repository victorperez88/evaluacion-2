from locust import HttpUser, task, between

class WebsiteUser(HttpUser):
    wait_time = between(1, 2)

    @task(2)
    def root(self):
        self.client.get("/")

    @task(1)
    def login_ok(self):
        self.client.post("/login", json={"username":"tester","password":"123456"})
